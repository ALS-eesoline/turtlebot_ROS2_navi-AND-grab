// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROS2_ARUCO_INTERFACES__MSG__ARUCO_MARKERS_HPP_
#define ROS2_ARUCO_INTERFACES__MSG__ARUCO_MARKERS_HPP_

#include "ros2_aruco_interfaces/msg/detail/aruco_markers__struct.hpp"
#include "ros2_aruco_interfaces/msg/detail/aruco_markers__builder.hpp"
#include "ros2_aruco_interfaces/msg/detail/aruco_markers__traits.hpp"

#endif  // ROS2_ARUCO_INTERFACES__MSG__ARUCO_MARKERS_HPP_
